const scrollToTopButton = 
document.getElementByID("scrollToTopBtn");

function scrollToTop(){
  document.documentElement.scrollTo({
    top:0,
    behavior:"smooth",
  })
}

scrollToTopButton.addEventListener("click",scrollToTop);